#define LDR_PORT A0
#define OXIMETRY_PORT A3
#define HANDTEMP_PORT A1
#define GSR_PORT A1
#define FSR_PORT A2


