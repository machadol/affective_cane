#include <HCSR04.h>

//Definitions of the pins
#define triggerPin 11
#define echoPin 10


int getDistanceToFloor();
